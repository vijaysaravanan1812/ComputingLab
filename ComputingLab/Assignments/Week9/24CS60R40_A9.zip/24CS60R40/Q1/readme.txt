
I have picking a 5 samples 
Here I am considering the 500 operations as one sample

To run the code
 g++ -g 24CS60R40_A9_part1.cpp