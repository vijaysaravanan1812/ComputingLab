
I have Picking 5 samples from 500 operation
Here I am do not considering the 500 operations as one sample
each 500 Operation take huge time because of sequencial operation

To run the code
 g++ -g 24CS60R40_A9_part2.cpp