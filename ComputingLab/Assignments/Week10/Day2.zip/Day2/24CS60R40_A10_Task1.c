
#include<stdio.h>
#include<sys/types.h>
#include<unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define UNPROCESSED -1
#define PROCESSED 0

struct MatrixDetails {
    int **Matrix;
    int Rows;
    int Cols;
    int *A;
    int *B;
};

pthread_mutex_t mutexMatrix, mutexArray;
int updatesProcessed = 0;


void *Chaos(void *param) {
    
    struct MatrixDetails *details = (struct MatrixDetails *)param;
    int **matrix = details->Matrix;
    int *A = details->A;
    int *B = details->B;
    int rows = details->Rows;
    int cols = details->Cols;

    printf("I am chaos\n");

    for (int updates = 0; updates < 30; updates++) {
        int i = rand() % rows;
        int j = rand() % cols;
        int k = (rand() % 1000) + 1;

        // Lock matrix to update a random element
        pthread_mutex_lock(&mutexMatrix);
        matrix[i][j] = k;
        printf("Chaos: Updated element at cell %d x %d with value %d\n", i, j, k);
        pthread_mutex_unlock(&mutexMatrix);

   
        pthread_mutex_lock(&mutexArray);
        for (int index = 0; index < 1000; index++) {

            //Finding the Free space by Linear search
            if (A[index] == 0) {
                A[index] = i;
                B[index] = UNPROCESSED;
                break;
            }
        }
        pthread_mutex_unlock(&mutexArray);

    
        sleep(2);
    }

    printf("CHAOS THREAD ENDS\n");
    return NULL;
}


void *Order(void *param) {

    struct MatrixDetails *details = (struct MatrixDetails *)param;
    int **matrix = details->Matrix;
    int *A = details->A;
    int *B = details->B;
    int rows = details->Rows;
    int cols = details->Cols;

    printf("I am order\n");

    while (updatesProcessed < 30) {
        int rowToProcess = -1;

        // Check the shared arrays A and B for unprocessed rows
        pthread_mutex_lock(&mutexArray);
        for (int index = 0; index < 1000; index++) {
            if (B[index] == UNPROCESSED) {
                rowToProcess = A[index];
                B[index] = PROCESSED;

                printf("Order: Detected updated element at row %d\n", rowToProcess);
                break;
            }
        }
        pthread_mutex_unlock(&mutexArray);

        if (rowToProcess != -1) {

            // lock the matrix row, sort that row and unlock
            pthread_mutex_lock(&mutexMatrix);
            printf("Older row %d: ", rowToProcess);
            for (int j = 0; j < cols; j++) {
                printf("%d ", matrix[rowToProcess][j]);
            }
            printf("\n");

            
            for (int j = 0; j < cols - 1; j++) {
                for (int k = j + 1; k < cols; k++) {
                    if (matrix[rowToProcess][j] > matrix[rowToProcess][k]) {
                        int temp = matrix[rowToProcess][j];
                        matrix[rowToProcess][j] = matrix[rowToProcess][k];
                        matrix[rowToProcess][k] = temp;
                    }
                }
            }

            printf("New row %d: ", rowToProcess);
            for (int j = 0; j < cols; j++) {
                printf("%d ", matrix[rowToProcess][j]);
            }
            printf("\n");
            pthread_mutex_unlock(&mutexMatrix);

            updatesProcessed++;
        }


    }

    printf("ORDER THREAD ENDS\n");
    return NULL;
}

void PrintMatrix(int ** Matrix ,int Rows , int Col){
    for(int i = 0 ; i < Rows; i++){
        for(int j = 0 ; j < Col; j++){
            printf("%d \t" , Matrix[i][j]);
        }
        printf("\n");
    }
}

int main(int argc, char *argv[]){

    pthread_mutex_init(&mutexMatrix, NULL);
    pthread_mutex_init(&mutexArray, NULL);

    if(argc < 3){
        printf("Usage %s <Row> <Col>\n", argv[0]);
        exit(1);
    }
    int Rows = atoi(argv[1]);
    int Cols = atoi(argv[2]);
    int ** Matrix =  (int **)malloc(Rows * sizeof(int *));
    for(int i = 0 ; i < Cols; i++){
        Matrix[i] = (int *)malloc(Cols * sizeof(int));
    }

    for (int i = 0; i < Rows; i++) {
        for (int j = 0; j < Cols; j++) {
            Matrix[i][j] = (rand() % 1000) + 1;
        }
    }


    printf("Random Matrix M of size (%d, %d) is created.\n", Rows, Cols);
    PrintMatrix(Matrix , Rows, Cols);

    int A[1000] = {0};
    int B[1000] = {0};
    printf("Shared Arrays A and B are created.\n");

    int processCount = 0;
    pid_t OrderID[6];
    pid_t PID;
    for(int i = 0 ; i < 6 ; i++){
        PID = fork();
        if(PID < 0){
            perror("Fork Failed\n");
            exit(1);
        }
        if(PID == 0){
            printf("Child Process\n");
   
            processCount++;
            printf("Child Process %d PID %d, parent PID = %d\n ", processCount, getpid() , getppid());
            while (1)
            {
                sleep(5);
            }
            
        }else if(PID != 0){
            printf("Parent Process\n");
            
            OrderID[i] = PID;
            
            
            break;
        }
    }
        printf("Child Processes\n");
            for (int i = 0; i < 6; i++)
            {
                printf("%d \t", OrderID[i]);
            }printf("\n");


    // pid_t ChaosID[3];
    // for(int j = 0 ; j < 3 ; j++){
    //     ChaosID[j] = fork(); 
    // }
    // if(p < 0){
    //     perror("Fork Fails");
    //     _exit(1);
    // }
    // if(p == 0){
    //     printf("Child Process %d and my parent %d\n" , p, getpid());
    // }else{
    //     printf("Parent process %d\n", p);
    // }
    return 0;
}